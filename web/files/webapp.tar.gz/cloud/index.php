<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<title>Opacity Storage</title>
</head>
<body>
<h1><strong>5 Minutes File Upload</strong> - Personal Cloud Storage</h1>
<?php
session_start();
    $BASE_URL = strtok($_SERVER['REQUEST_URI'],'?');
    if (isset($_POST['url'])){
        $url = $_POST['url'];
    
        
    if (preg_match('/\.(jpeg|jpg|png|gif)$/i', $url)) {
	
        exec("wget -P /var/www/html/cloud/images {$url}");
	echo '<div class="form-group">Transferring file..<br></div>';
	echo '<div class="form-group"><img src="load.gif" alt="loading" width="500" ></div>';
	$name = basename($url);
	$link = "/cloud/images/$name";
        $_SESSION['link'] = $link;
	
        header( "refresh:3;url=storage.php" );
	
	} else {        
		echo '<div class="form-group">Please select an image</div>';
    }
}


    
?>
	<div class="form-group">
<p style="text-align:center;"><img src="folder.png" alt="Folder" width="40%" height="40%"></p>
    <label for="title"><span>External Url:</span></label>
    <form name='upload' method='post' action="<?php echo $BASE_URL; ?>">
        <input type='text' id='url' name='url'  class="form-controll"/><br>
</div>
	<div class="form-group">
    <button type="submit">Upload image
</form>
    
  </div>

  </button>
</form>
</div>
</body>
</html>
