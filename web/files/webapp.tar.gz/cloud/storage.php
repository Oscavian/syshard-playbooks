<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<title>Opacity Storage</title>
</head>
<body>
<h1><strong>5 Minutes File Upload</strong> - Personal Cloud Storage</h1>
<?php
session_start();
$link = $_SESSION['link'];
$IP = $_SERVER['SERVER_ADDR'];

echo '<div class="form-group"><img src="'.$link.'" width="100%" height="100%"/></div>';


echo '<div class="form-group"><label for="title">Image Link: </label>';
echo '<input type="url" id="url" name="url"  class="form-controll" value="http://'.$IP.''.$link.'"/><br>';

echo '<div class="form-group"><label for="title">HTML: </label>';
$HTML = htmlspecialchars('<a href="http://'.$IP.''.$link.'"><img src="http://'.$IP.''.$link.'" alt="background" border="0" /></a>');
echo '<input type="url" id="url" name="url" class="form-controll" value="'.$HTML.'"';


?>
</div>
	<div class="form-group">
  </div>
</div>
</body>
</html>
